class Render {
  render() {}

  renderGraphics() {}

  clear() {}
}

export default Render
