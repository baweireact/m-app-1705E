module.exports = [
  'last 3 versions',
  'Android >= 4.1',
  'ios >= 8'
]
