module.exports = {
  OUTPUT_DIR: 'dist',
  SOURCE_DIR: 'src',
  TEMP_DIR: '.temp',
  NPM_DIR: 'npm',
  ENTRY: 'app'
}
