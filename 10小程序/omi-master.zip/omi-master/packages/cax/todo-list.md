http://tutorials.jenkov.com/svg/index.html

todo:

* 自动轮播支持 http://tavmjong.free.fr/blog/wp-content/uploads/BATMAN/batman_logos.svg （间隔时间支持）
* debug bounds box
* pasition easing function

* Transformation + tojs
* Transformation 
* boundsX 和 boundsY 
* text
* image(由于 svg image 设计得很失败，所以渲染 image 和 web 有差异，请使用 transform 对image 进行变形，而不使用 width和height)
* SVG Viewport and View Box
* event handler
* jsx support(extend omip)

vscode 安装 lit-html 使 html`内容` 高亮


import testSVG from 'svg/test'

renderSVG(testSVG, 'canvas-id', this)


https://dmtrbrl.github.io/svg-path-editor/
