import Todo from './todo'

const todo = new Todo()

export default todo
