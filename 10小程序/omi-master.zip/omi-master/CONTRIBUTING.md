# Contributing

Any form of contribution is welcome.

## Acknowledgements

- vorshen <987733967@qq.com>
- pasturn <pasturn@qq.com>
- xcatliu <xcatliu@gmail.com>

The above contributors have been officially released by Tencent.

## Tencent open source contributor incentives

We very much welcome developers to contribute to Tencent's open source, and we will also give them incentives to acknowledge and thank them. Here we provide an official description of Tencent's open source contribution. Specific contribution rules for each project are formulated by the project team. Developers can choose the appropriate project and participate according to the corresponding rules. The Tencent Project Management Committee will report regularly to qualified contributors and awards will be issued by the official contact.
