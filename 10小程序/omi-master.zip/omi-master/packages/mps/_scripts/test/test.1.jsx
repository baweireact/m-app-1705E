bb?<view>show</view>:<view>hide</view>
